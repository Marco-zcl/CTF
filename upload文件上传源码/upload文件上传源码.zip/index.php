<html>
<body>
<?php 
$flag = "flag{test}";
?>

<form action="index.php" method="post" enctype="multipart/form-data">
我的名字是2tina，给我一个图像文件，而不是PHP文件。<br>
<br>
<input type="file" name="file" id="file" /> 
<input type="submit" name="submit" value="Submit" />
</form>

<?php
function global_filter(){
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
        $file_ext = strtolower(pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION));
        $allowexts = array('jpg', 'gif', 'jpeg', 'bmp');
        if (!in_array($file_ext, $allowexts)) {
            die("Please provide an image file, not a PHP file.");
        }
    } else {
        die("文件上载无效。.");
    }
}

global_filter();

if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
    $file_ext = strtolower(pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION));

    if ((stripos($_FILES["file"]["type"], 'image') !== false) && ($_FILES["file"]["size"] < 10 * 1024 * 1024)) {
        $new_filename = "bugku" . date('dHis') . "_" . rand(1000, 9999) . "." . $file_ext;
        $upload_dir = "./upload/";
        $target_path = $upload_dir . $new_filename;

        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_path)) {
            echo "Upload Success<br>";
            echo "Stored in: <a href='" . $target_path . "' target='_blank'>" . $target_path . "</a><br>";
        } else {
            echo "Error uploading file.<br>";
        }
    } else {
        echo "Please provide an image file less than 10MB in size.<br>";
    }
}
?>
</body>
</html>
